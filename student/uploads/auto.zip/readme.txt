Auto Macro Recorder v5.81 trial / Auto Macro Recorder Pro v5.2 trial

support Windows Vista and Windows 7 !

--------------------------------------------
If you couldn't see or edit the scp file in Win7 by Windows Explorer but could see it by AutoMacroRecorder when you open the script file, It was just a matter of SECURITY PRIVILEGES that you could access files in Program Files, once you added ALL the privileges to the USER GROUP, or install AutoMacroRecorder into other folder, you'll be able to edit the files which created by software.

--------------------------------------------

Recently We found that some anti-spy / anti-virus software classify our Macro software and other
same types as commercial key logger,  Trojan  or virus because Macro Software has the capability
to record/save your keystroke( for replay ). 
In the fact of  that they don't distinguish from category of Macro recoder, they just put the 
Marco software into key logger irrespectively. 

Hereby we seriously declared that Auto Macro Recorder is Macro software and its copyright 
belongs to readmesoft. We never and are unable to steal or collect any information from our
 customers through the program, furthermore, we did not and would not provide registration 
information of our clients to any company or organizations. Any users who download the 
Auto Macro Recorder from "readmesoft.com" "macro-recorder.com" "macro-program.com" "download.com" 
could operate safely.

As Macro software has the capable of recording and replaying keystroke operations, so please 
highly keep your eyes open and precaution if the program in your computer is not downloaded or 
installed by yourself.   Finally, we also kindly suggest that you'd better not to record your 
useful password such as credit, email, bank account, etc. into script files, for in any circumstances on using macro software, such operations are not safe. 



WinNT users:
Install Service pack 4 above for WinNT and Internet Explorer 4.0 above.
Then extract autont.zip to the installation folder of Auto Macro Recorder to overwrite the auto.exe.

www.readmesoft.com
support@readmesoft.com
