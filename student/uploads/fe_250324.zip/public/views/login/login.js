document.getElementById("loginButton").addEventListener("click", function () {
  document.getElementById("loginForm").style.display = "block";
});

const apiUrl = "https://localhost:7213"

async function login()
{
  let data =
  {
    username: document.getElementById("username").value,
    password: document.getElementById("password").value
  }

  let token = "";

  await post("login",data, res=>token = res)

  await setTokenToCookie(token)

  window.location.href = "https://google.com"
}

async function post(url,data, callback)
{
  await fetch(`${apiUrl}/${url}`, {
    method: "POST",
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
    }).then(callback);
}

let a;
async function sampleCall(url)
{
  await fetch(`${apiUrl}/${url}`,{
    method: "GET",
    headers: {"Authorization": `Bearer ${getCookie('jwt')}`}
  }).then(res => a = res);
}

async function setTokenToCookie(token)
{
  document.cookie = `jwt = ${await token.text()}`;
}

function getCookie(cname) {
  let name = cname + "=";
  let ca = document.cookie.split(';');
  for(let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

document.getElementById("submit-btn").addEventListener("click", login);

  /*var allowedDomain = "@fpt.edu.vn"; // Domain của FPT Email

  if (email.endsWith(allowedDomain)) {
    document.getElementById("message").innerText = "Login successful!";
    // Đặt trạng thái đã đăng nhập
    localStorage.setItem("isLoggedIn", true);
    // Thực hiện hành động sau khi đăng nhập thành công, ví dụ: điều hướng đến trang chính
    window.location.href = "../home/home.html"; // điều hướng đến trang home
  } else {
    document.getElementById("message").innerText =
      "Please enter a valid FPT email address";
  }*/

document.getElementById("loginButton").addEventListener("click", function () {
  document.getElementById("loginForm").style.display = "block";
});
