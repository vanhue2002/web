﻿namespace MarketingEvent.Database.Authentication.Dtos
{
    public class RoleDto
    {
        public Guid Id { get; set; }
        public string RoleName { get; set; }
    }
}